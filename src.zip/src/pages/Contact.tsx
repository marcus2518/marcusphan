// src/pages/Contact.tsx
import React from "react";

const Contact: React.FC = () => {
  return <div>Jimmy</div>;
};

export default Contact;

// src/pages/About.tsx
import React from "react";

const About: React.FC = () => {
  return <div>bonjour Jimmy</div>;
};

export default About;

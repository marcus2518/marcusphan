// src/pages/Home.tsx
import React from "react";

const Home: React.FC = () => {
  return <div>Jimmy</div>;
};

export default Home;
